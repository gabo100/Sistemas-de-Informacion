<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="0; url=pages/login.php">
<title>SB Admin 2</title>
<script language="javascript">
    window.location.href = "pages/login.php";
</script>
</head>
<body>
Go to <a href="pages/login.html">/pages/login.html</a>
</body>
</html>
